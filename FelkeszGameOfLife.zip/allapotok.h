#ifndef ALLAPOTOK_H_INCLUDED
#define ALLAPOTOK_H_INCLUDED

#include "strukturak.h"
#include "tabla_muveletek.h"
#include "grafika.h"

enum Allapot programgerinc(Matrix* a, Matrix* b, Panel p, double esely, enum Allapot allapot, int szamlalo, bool megy, int* valami);

#endif // ALLAPOTOK_H_INCLUDED
